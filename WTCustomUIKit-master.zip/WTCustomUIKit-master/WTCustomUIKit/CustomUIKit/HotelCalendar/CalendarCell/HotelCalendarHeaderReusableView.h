//
//  HotelCalendarHeaderReusableView.h
//  HotelCalendar
//
//  Created by Wynter on 2017/10/17.
//  Copyright © 2017年 Wynter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HotelCalendarHeaderReusableView : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;

@end
