//
//  CompanySelectTypeItem.m
//  WTCustomUIKit
//
//  Created by Wynter on 2018/4/20.
//  Copyright © 2018年 Wynter All rights reserved.
//

#import "CompanySelectTypeItem.h"

@implementation CompanySelectTypeItem

@end

