//
//  MenuSelectTableViewCell.h
//  Menu
//
//  Created by Wynter on 16/7/21.
//  Copyright © 2016年 wynter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuSelectTableViewCell : UITableViewCell

@end
