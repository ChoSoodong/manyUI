//
//  MenuSelectItem.h
//  Menu
//
//  Created by Wynter on 16/7/21.
//  Copyright © 2016年 wynter. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuSelectItem : NSObject
@property (nonatomic,strong)NSString *iconImage;
@property (nonatomic,strong)NSString *title;
@end
